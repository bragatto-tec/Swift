//
//  StatisticView.swift
//  Pokedex2
//
//  Created by Aluno Mack on 21/03/25.
//

import SwiftUI

struct StatisticView: View {
    var body: some View {
        Text(/*@START_MENU_TOKEN@*/"Hello, World!"/*@END_MENU_TOKEN@*/)
    }
}

struct StatisticView_Previews: PreviewProvider {
    static var previews: some View {
        StatisticView()
    }
}
