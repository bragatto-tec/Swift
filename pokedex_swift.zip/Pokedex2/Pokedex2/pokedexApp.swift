//
//  pokedexApp.swift
//  pokedex
//
//  Created by Aluno Mack on 20/03/25.
//

import SwiftUI

@main
struct Pokedex2App: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}
